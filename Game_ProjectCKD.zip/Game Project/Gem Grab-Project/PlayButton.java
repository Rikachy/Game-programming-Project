import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

public class PlayButton extends Button
{
    public PlayButton()
    {
        GreenfootImage img = getImage();
        int w = img.getWidth();
        int h = img.getHeight();

        img.scale(w / 2, h / 2);
        setImage(img);

        prepareHoverImages();
    }

    public void act()
    {
        super.act();  // hover behavior

        if (Greenfoot.mouseClicked(this))
        {
            Greenfoot.setWorld(new LevelMenu());
        }
    }
}
