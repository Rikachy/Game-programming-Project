import greenfoot.*;

public class CreditsButton extends Button
{
    public CreditsButton()
    {
        GreenfootImage img = getImage();
        int w = img.getWidth();
        int h = img.getHeight();

        img.scale(w / 2, h / 2);      
        setImage(img);

        prepareHoverImages();  // IMPORTANT: prepare scaled hover image
    }

    public void act()
    {
        super.act();  // handle hover behavior

        if (Greenfoot.mouseClicked(this))
        {
            Greenfoot.setWorld(new CreditsWorld());
        }
    }
}
