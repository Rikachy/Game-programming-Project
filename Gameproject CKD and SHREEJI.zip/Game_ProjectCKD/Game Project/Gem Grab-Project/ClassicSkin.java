import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ClassicSkin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ClassicSkin extends SkinsButton
{
    /**
     * Act - do whatever the ClassicSkin wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        super.act();
    }
}
